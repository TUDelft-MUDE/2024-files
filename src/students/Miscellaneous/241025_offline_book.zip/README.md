This book was created on Friday, October 25, 2024.

The zip file in this zip file is an offline copy of the MUDE Textbook. It is only to be shared with MUDE students from the 2024-25 academic year.

If you have any questions contact MUDE-CEG@tudelft.nl

To use the book unzip the zip file, find index.html and open it in a browser. Some interactive features will not work, but you can read it offline.