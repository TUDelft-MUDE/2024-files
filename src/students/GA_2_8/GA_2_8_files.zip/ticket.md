# Ticket

_Fill out each of the 6 items below to complete your ticket submission._

**Make sure you replace everything after the `:` with your own information!**

Group: GROUP_NAME 
Month: MM  
Day: DD  
Hour: HH (24-HOUR FORMAT)  
Minute: MM  
Justification: |  
WRITE_AS_MUCH_AS_YOU_WANT_HERE
USE_AS_MANY_LINES_AS_NEEDED