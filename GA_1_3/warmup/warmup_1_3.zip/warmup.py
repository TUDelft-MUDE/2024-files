def try_me(a_string):
    print(a_string)
    return a_string